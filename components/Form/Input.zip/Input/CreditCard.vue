<template>
  <div class="flex-between flex-col lg:flex-row gap-2">
    <FormInput
      :id="id"
      v-model="model.number"
      v-mask="'####-####-####-####'"
      class="w-full lg:max-w-64"
      :label="label ?? 'Номер карты'"
      :required="required"
      type="text"
      inputmode="numeric"
      min="0"
      minlength="9"
      maxlength="9"
      placeholder="____-____-____-____"
      :error="error"
    />
    <FormInput
      :id="id"
      v-model="model.valid"
      v-mask="'##/##'"
      :label="label ?? 'Срок'"
      :required="required"
      type="text"
      inputmode="numeric"
      min="0"
      minlength="9"
      maxlength="9"
      placeholder="__/__"
      :error="error"
    />
  </div>
</template>

<script setup lang="ts">
import type { IInput } from "@/types/components";

const model = defineModel<{ number: string; valid: string }>();
defineProps<IInput>();
</script>
