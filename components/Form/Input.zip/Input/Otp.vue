<template>
  <div>
    <div class="flex justify-center gap-2 my-4">
      <input
        v-for="input in 6"
        :id="'otp-input-' + input"
        :key="input"
        v-mask="'#'"
        type="text"
        inputmode="numeric"
        maxlength="1"
        class="py-2 text-center w-10 border rounded flex-center otp-inp outline-none border-gray-300 transition-300 focus-within:!border-red"
        min="0"
        max="9"
        @input="onInputChange"
        @keyup="onInputKeyup"
      >
    </div>
    <p class="text-gray">
      Не получили код?
      <span v-if="isTimeOut" class="text-red cursor-pointer" @click="startTimer"
        >Отправить заново</span
      >
      <span v-else class="text-red">
        {{ timer }}
      </span>
    </p>
  </div>
</template>

<script setup lang="ts">
let { otpCode } = defineProps<{ otpCode: string }>();

const timer = ref();
const isTimeOut = ref(false);
let second = 60;
let intervalId: NodeJS.Timeout;

function startTimer() {
  second = 60;
  isTimeOut.value = false;
  intervalId = setInterval(() => {
    second--;
    if (second == 0) {
      isTimeOut.value = true;
      clearInterval(intervalId);
    }
    const s = second < 10 ? `0${second}` : second;
    timer.value = `00:${s}`;
  }, 1000);
}
startTimer();

function onInputChange(e: Event) {
  const target = e.target as HTMLInputElement;
  const val = target.value;
  if (isNaN(+val)) {
    target.value = "";
    return;
  }
  if (val !== "") {
    otpCode += val;
    const next = target.nextSibling as HTMLInputElement;
    if (next) {
      next.focus();
    }
  }
}

function onInputKeyup(e: KeyboardEvent) {
  const target = e.target as HTMLInputElement;
  const key = e.key.toLowerCase();
  if (key === "backspace" || key === "delete") {
    target.value = "";
    const prev = target.previousSibling as HTMLInputElement;
    const lastValIndex = otpCode.lastIndexOf(prev.value);
    const curOtpVal = otpCode
      .split("")
      .slice(0, lastValIndex + 1)
      .join("");
    otpCode = curOtpVal;
    if (prev) {
      prev.focus();
    }
    return;
  }
}
</script>
